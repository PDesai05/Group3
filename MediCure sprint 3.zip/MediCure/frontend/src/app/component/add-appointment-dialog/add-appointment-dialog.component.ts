import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-appointment-dialog',
  templateUrl: './add-appointment-dialog.component.html',
  styleUrls: ['./add-appointment-dialog.component.scss']
})
export class AddAppointmentDialogComponent {
  appointmentForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<AddAppointmentDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.appointmentForm = this.fb.group({
      pname: ['', Validators.required],
      phone: ['', Validators.required],
      p_age: ['', Validators.required],
      a_date: ['', Validators.required],
      a_time: ['', Validators.required],
      problem: ['', Validators.required],
    });
  }

  onSubmit() {
    if (this.appointmentForm.valid) {
      // Logic to handle form submission, e.g., send the data to the backend
      console.log('Form Data:', this.appointmentForm.value);
      debugger
      this.dialogRef.close(this.appointmentForm.value);
    }
  }

  onCancel(): void {
    this.dialogRef.close();
  }
}
