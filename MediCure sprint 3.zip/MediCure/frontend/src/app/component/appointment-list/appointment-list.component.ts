import { Component } from '@angular/core';
import { AppointmentService } from '../../services/appointment.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-appointment-list',
  templateUrl: './appointment-list.component.html',
  styleUrl: './appointment-list.component.scss'
})
export class AppointmentListComponent {
  appointments: any[] = [];
  userType: string | undefined;
  constructor(private appointmentService: AppointmentService,
    private router: Router
  ) {
    this.userType = localStorage.getItem('userType') == 'doctor' ? 'doctor' : 'user';
  }
  ngOnInit(): void {
    
    this.getAppointments();
  }

  getAppointments(): void {
    this.appointmentService.getAppointments().subscribe(
      (data: any[]) => {
        this.appointments = data;
      },
      error => {
        console.error('Error fetching appointment data:', error);
      }
    );
  }
  navigateToAddAppointment(): void {
    this.router.navigate(['/add-appointment']);
  }

}
