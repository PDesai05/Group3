import { Request, Response } from 'express';
import Appointment from '../models/Appointment';
export class AppointmentController {
// Example function to create a new appointment
public createAppointment = async (req: Request, res: Response) => {
  try {
    const newAppointment = new Appointment({
      pname: req.body.pname,
      phone: req.body.phone,
      p_age: req.body.p_age,
      a_date: req.body.a_date,
      a_time: req.body.a_time,
      problem: req.body.problem,
      doc_id: req.body.doc_id,
      pat_id: req.body.pat_id
    });

    await newAppointment.save();
    res.status(201).json(newAppointment);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Example function to get all appointments
public getAppointments = async (req: Request, res: Response) => {
  try {
    const appointments = await Appointment.find() .populate('doc_id', 'name')
    .populate('pat_id', 'name');;
    res.status(200).json(appointments);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}
}
