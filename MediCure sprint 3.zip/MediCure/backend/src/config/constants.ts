export class Constants{
    public static readonly SUCCEESS = "success";
    public static readonly FAIL = "fail";
}